/** @format */

'use strict'

import React, { Component } from 'react'
import {
  FlatList,
  View,
  ListView,
  TouchableOpacity,
  TextInput,
  Image,
  Text,
} from 'react-native'
import { flatten } from 'lodash'

import TimeAgo from 'react-native-timeago'
import HTML from 'react-native-render-html'
import css from './style'
import { Languages } from '@common'
import Api from '@services/Api'
import Icon from '@expo/vector-icons/SimpleLineIcons'
import User from '@services/User'

import { fetchComments } from '@redux/actions'
import { connect } from 'react-redux'

class Comment extends Component {
  constructor(props) {
    super(props)
    this.state = {
      dataSource: new ListView.DataSource({
        rowHasChanged: (r1, r2) => r1 !== r2,
      }),
      txtComment: '',
      addComment: false,
      userData: '',
    }
    this.fetchDataUser()
  }

  fetchDataUser() {
    var self = this
    User.getUser().then((data) => {
      self.setState({
        userData: data,
      })
    })
  }

  componentDidMount() {
    this.props.fetchComments(this.props.post.id)

    this.setState({ dataSource: this.getDataSource(this.props.comments) })
  }

  getDataSource(comments) {
    return this.state.dataSource.cloneWithRows(comments)
  }

  renderRow({ item }) {
    const comment = item

    const htmlStyle = {
      p: { color: '#888', fontSize: 14, lineHeight: 22 },
    }
    const contentCmt = comment.content.rendered
    const authorName = comment.author_name
    const timePostCmt = comment.date
    return (
      <View style={css.itemComment}>
        <View style={css.itemHeadComment}>
          <Image
            source={require('@images/icon-set/profile.png')}
            style={css.avatarComment}
          />
          <View>
            <Text style={css.authorName}>{authorName}</Text>
            <Text style={css.timeAgoText}>
              <TimeAgo time={timePostCmt} hideAgo={false} />
            </Text>
          </View>
        </View>
        <View style={css.commentHTML}>
          <HTML tagsStyles={htmlStyle} html={contentCmt} />
        </View>
      </View>
    )
  }

  submitComment() {
    var self = this
    var post = self.props.post
    const id = post.id
    var commentData = {
      post: id,
      author_name: 'Guest',
      content: this.state.txtComment,
    }

    Api.createComment(commentData).then((data) => {
      if (data != null) {
        self.setState({
          addComment: true,
          txtComment: '',
        })
      }
    })
  }

  render() {
    const renderCommentInput = () => {
      if (!this.state.userData) {
        return <View />
      }
      if (this.state.addComment) {
        return <Text>{Languages.commentSubmit}</Text>
      }
      return (
        <View style={{flex: 1}}>
        <Text style={css.headCommentText}>{Languages.comment}</Text>
          <View style={css.inputCommentWrap}>
            <TextInput
              style={css.inputCommentText}
              underlineColorAndroid="transparent"
              autoCorrect={false}
              multiline={true}
              onChangeText={(text) => this.setState({ txtComment: text })}
              placeholder={Languages.yourcomment}
              onSubmitEditing={this.submitComment.bind(this)}
            />
          </View>
          <TouchableOpacity
            onPress={this.submitComment.bind(this)}
            style={css.sendView}>
            <Icon
              name="cursor"
              size={16}
              color="white"
              style={css.sendButton}
            />
            <Text style={css.sendText}>{Languages.send}</Text>
          </TouchableOpacity>
        </View>
      )
    }

    const { comments } = this.props

    return (
      <View style={css.wrapComment}>
        {renderCommentInput()}
        {comments.length != 0 && <View style={css.wrapListComment}>
          <FlatList
            data={comments}
            keyExtractor={(item, index) => `comment-${item.id || index}`}
            renderItem={this.renderRow.bind(this)}
          />
        </View>}
      </View>
    )
  }
}

const mapStateToProps = ({ comments }, ownProps) => {
  const postId = ownProps.post.id
  let postComments = []

  if (comments.list.length > 0) {
    comments.list.map((comment) => {
      if (typeof comment[postId] != 'undefined') {
        postComments = flatten(comment[postId])
      }
    })
  }
  return { comments: postComments }
}
export default connect(mapStateToProps, { fetchComments })(Comment)
