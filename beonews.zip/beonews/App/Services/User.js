/** @format */

import UserModal from './UserModal'

const User = new UserModal()
export default User
