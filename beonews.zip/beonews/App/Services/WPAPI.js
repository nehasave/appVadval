import WPAPI from "wpapi";
import Config from '@common/Config';

var wpApi = new WPAPI({
    endpoint: Config.URL.root + '/wp-json'
});

export default wpApi;
