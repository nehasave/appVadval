/** @format */

import { Config } from '@common'
import WordpressApi from './WordpressApi'

const Api = new WordpressApi({
  url: Config.URL.root,
  logo: Config.URL.logo,
})

export default Api
